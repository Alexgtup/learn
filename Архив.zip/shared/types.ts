export type ModuleItem = {
  id: string;
  title: string;
  week: string;
  weekOrder: number;
  order: number;
  content: string;
  builtin: boolean;
};

export type CheckMap = Record<string, Record<string, boolean>>;

export type AppStateDto = {
  modules: ModuleItem[];
  checks: CheckMap;
};

export type CreateModuleInput = {
  title?: string;
  week?: string;
  content: string;
};

export type GlossaryTerm = {
  slug: string;
  term: string;
  aliases: string[];
  content: string;
  updatedAt: string;
};

export type GlossaryTermSummary = {
  slug: string;
  term: string;
  aliases: string[];
};

export type UpsertGlossaryInput = {
  term: string;
  aliases?: string[];
  content: string;
};