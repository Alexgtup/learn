import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import type { AppStateDto, CheckMap, CreateModuleInput, ModuleItem } from "../../shared/types.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataDir = path.resolve(__dirname, "../data");
const storePath = path.join(dataDir, "store.json");

type PersistedState = AppStateDto;

const initialState: PersistedState = {
  modules: [],
  checks: {}
};

async function ensureStore(): Promise<void> {
  await mkdir(dataDir, { recursive: true });
  try {
    await readFile(storePath, "utf8");
  } catch {
    await writeState(initialState);
  }
}

async function readState(): Promise<PersistedState> {
  await ensureStore();
  const raw = await readFile(storePath, "utf8");
  return JSON.parse(raw) as PersistedState;
}

async function writeState(state: PersistedState): Promise<void> {
  await mkdir(dataDir, { recursive: true });
  await writeFile(storePath, JSON.stringify(state, null, 2), "utf8");
}

function sortModules(modules: ModuleItem[]): ModuleItem[] {
  return modules.toSorted((a, b) => {
    return a.weekOrder - b.weekOrder || a.order - b.order || a.title.localeCompare(b.title, "ru");
  });
}

export async function getState(): Promise<AppStateDto> {
  const state = await readState();
  return {
    modules: sortModules(state.modules),
    checks: state.checks
  };
}

export async function createModule(input: CreateModuleInput): Promise<ModuleItem> {
  const state = await readState();
  const customCount = state.modules.filter((module) => !module.builtin).length;
  const module: ModuleItem = {
    id: `custom-${crypto.randomUUID()}`,
    title: input.title?.trim() || "Без названия",
    week: input.week?.trim() || "Мои модули",
    weekOrder: 99,
    order: customCount + 1,
    content: input.content.trim(),
    builtin: false
  };

  state.modules.push(module);
  await writeState(state);
  return module;
}

export async function deleteModule(id: string): Promise<boolean> {
  const state = await readState();
  const before = state.modules.length;
  state.modules = state.modules.filter((module) => module.id !== id);
  delete state.checks[id];
  await writeState(state);
  return state.modules.length !== before;
}


export async function updateCheck(moduleId: string, taskIndex: number, checked: boolean): Promise<CheckMap[string]> {
  const state = await readState();
  const exists = state.modules.some((module) => module.id === moduleId);
  if (!exists) {
    throw new Error("MODULE_NOT_FOUND");
  }

  state.checks[moduleId] = state.checks[moduleId] || {};
  state.checks[moduleId][String(taskIndex)] = checked;
  await writeState(state);
  return state.checks[moduleId];
}
