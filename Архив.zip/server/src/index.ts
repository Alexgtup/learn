import path from "node:path";
import { fileURLToPath } from "node:url";
import { config } from "dotenv";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
config({ path: path.resolve(__dirname, "../.env") });

import cors from "cors";
import express from "express";
import { z } from "zod";
import { createModule, deleteModule, getState, updateCheck } from "./store.js";
import { deleteGlossaryTerm, getGlossaryTerm, listGlossary, upsertGlossaryTerm } from "./glossary.js";

const app = express();
const port = Number(process.env.PORT || 5175);

app.use(cors());
app.use(express.json({ limit: "2mb" }));

const createModuleSchema = z.object({
  title: z.string().optional(),
  week: z.string().optional(),
  content: z.string().min(1, "content is required")
});

const updateCheckSchema = z.object({
  taskIndex: z.number().int().nonnegative(),
  checked: z.boolean()
});

// простая защита write-эндпоинтов токеном из .env (ADMIN_TOKEN=что-то-длинное)
function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const token = req.header("x-admin-token");
  if (!process.env.ADMIN_TOKEN || token !== process.env.ADMIN_TOKEN) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }
  next();
}

const upsertGlossarySchema = z.object({
  term: z.string().min(1),
  aliases: z.array(z.string()).optional(),
  content: z.string().min(1)
});

app.get("/api/glossary", async (_req, res, next) => {
  try { res.json(await listGlossary()); } catch (error) { next(error); }
});

app.get("/api/glossary/:slug", async (req, res, next) => {
  try {
    const term = await getGlossaryTerm(req.params.slug);
    if (!term) { res.status(404).json({ message: "Not found" }); return; }
    res.json(term);
  } catch (error) { next(error); }
});

app.post("/api/glossary", requireAdmin, async (req, res, next) => {
  try {
    const input = upsertGlossarySchema.parse(req.body);
    res.status(201).json(await upsertGlossaryTerm(input));
  } catch (error) { next(error); }
});

app.put("/api/glossary/:slug", requireAdmin, async (req, res, next) => {
  try {
    const input = upsertGlossarySchema.parse(req.body);
    res.json(await upsertGlossaryTerm(input, req.params.slug));
  } catch (error) { next(error); }
});

app.delete("/api/glossary/:slug", requireAdmin, async (req, res, next) => {
  try {
    const deleted = await deleteGlossaryTerm(req.params.slug);
    if (!deleted) { res.status(404).json({ message: "Not found" }); return; }
    res.status(204).send();
  } catch (error) { next(error); }
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "fullstack-prep-journal-api" });
});

app.get("/api/state", async (_req, res, next) => {
  try {
    res.json(await getState());
  } catch (error) {
    next(error);
  }
});

app.post("/api/modules", async (req, res, next) => {
  try {
    const input = createModuleSchema.parse(req.body);
    const module = await createModule(input);
    res.status(201).json(module);
  } catch (error) {
    next(error);
  }
});

app.delete("/api/modules/:id", async (req, res, next) => {
  try {
    const deleted = await deleteModule(req.params.id);
    if (!deleted) {
      res.status(404).json({ message: "Module not found" });
      return;
    }
    res.status(204).send();
  } catch (error) {
    next(error);
  }
});

app.patch("/api/checks/:moduleId", async (req, res, next) => {
  try {
    const input = updateCheckSchema.parse(req.body);
    const checks = await updateCheck(req.params.moduleId, input.taskIndex, input.checked);
    res.json(checks);
  } catch (error) {
    next(error);
  }
});

app.use((error: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  if (error instanceof z.ZodError) {
    res.status(400).json({ message: "Validation failed", issues: error.issues });
    return;
  }

  if (error instanceof Error && error.message === "MODULE_NOT_FOUND") {
    res.status(404).json({ message: "Module not found" });
    return;
  }

  console.error(error);
  res.status(500).json({ message: "Internal server error" });
});

app.listen(port, () => {
  console.log(`API server listening on http://localhost:${port}`);
});
