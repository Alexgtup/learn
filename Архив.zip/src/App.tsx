import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Activity, AlertTriangle } from "lucide-react";
import type { AppStateDto, CreateModuleInput, GlossaryTermSummary, UpsertGlossaryInput } from "../shared/types";
import { api } from "./api";
import { ImportModal } from "./components/ImportModal";
import { ModuleContent } from "./components/ModuleContent";
import { ModuleSidebar } from "./components/ModuleSidebar";
import { Toast } from "./components/Toast";
import { GlossaryAdminModal } from "./components/GlossaryAdminModal";
import { GlossaryPage } from "./components/GlossaryPage";
import { buildGlossaryMatcher } from "./glossaryHighlight";
import { countTasks } from "./markdown";

const emptyState: AppStateDto = {
  modules: [],
  checks: {}
};

const emptyChecks: Record<string, boolean> = {};

function parseGlossaryHash(hash: string): string | null {
  const match = hash.match(/^#\/glossary\/(.+)$/);
  return match ? decodeURIComponent(match[1]) : null;
}

export function App() {
  const [state, setState] = useState<AppStateDto>(emptyState);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const [toast, setToast] = useState("");
  const toastTimer = useRef<number | null>(null);

  const [glossaryTerms, setGlossaryTerms] = useState<GlossaryTermSummary[]>([]);
  const [glossaryDraftTerm, setGlossaryDraftTerm] = useState<string | null>(null);
  const [glossarySlug, setGlossarySlug] = useState<string | null>(() => parseGlossaryHash(window.location.hash));

  const glossaryMatcher = useMemo(() => buildGlossaryMatcher(glossaryTerms), [glossaryTerms]);

  const activeModule = useMemo(() => {
    return state.modules.find((module) => module.id === activeId) || state.modules[0] || null;
  }, [activeId, state.modules]);

  const progress = useMemo(() => {
    let total = 0;
    let checked = 0;

    state.modules.forEach((module) => {
      total += countTasks(module.content);
      checked += Object.values(state.checks[module.id] || {}).filter(Boolean).length;
    });

    return total ? Math.round((checked / total) * 100) : 0;
  }, [state]);

  const showToast = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), 2400);
  }, []);

  const loadState = useCallback(async () => {
    try {
      setError(null);
      const nextState = await api.getState();
      setState(nextState);
      setActiveId((current) => current && nextState.modules.some((module) => module.id === current) ? current : nextState.modules[0]?.id || null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Не удалось загрузить данные");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadState();
  }, [loadState]);

  useEffect(() => {
    api.listGlossary().then(setGlossaryTerms).catch(() => { });
  }, []);

  useEffect(() => {
    const handler = () => setGlossarySlug(parseGlossaryHash(window.location.hash));
    window.addEventListener("hashchange", handler);
    return () => window.removeEventListener("hashchange", handler);
  }, []);

  // Глобальная защита: игнорировать multi-click (double/triple) по любому <summary>
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (typeof e.detail === "number" && e.detail > 1) {
        const target = (e.target as HTMLElement)?.closest?.("summary");
        if (target) {
          e.preventDefault();
          e.stopPropagation();
        }
      }
    };

    const onDbl = (e: MouseEvent) => {
      const target = (e.target as HTMLElement)?.closest?.("summary");
      if (target) {
        e.preventDefault();
        e.stopPropagation();
      }
    };

    document.addEventListener("click", onClick, true);
    document.addEventListener("dblclick", onDbl, true);
    // removed aggressive global pointerdown handler (caused interference)
    return () => {
      document.removeEventListener("click", onClick, true);
      document.removeEventListener("dblclick", onDbl, true);
    };
  }, []);

  async function handleCreateModule(input: CreateModuleInput) {
    const module = await api.createModule(input);
    setState((current) => ({ ...current, modules: [...current.modules, module] }));
    setActiveId(module.id);
    showToast("Модуль добавлен");
  }

  async function handleDeleteModule(id: string) {
    const module = state.modules.find((item) => item.id === id);
    if (!module || !confirm(`Удалить модуль "${module.title}"?`)) return;

    await api.deleteModule(id);
    setState((current) => {
      const modules = current.modules.filter((item) => item.id !== id);
      const checks = { ...current.checks };
      delete checks[id];
      return { modules, checks };
    });
    setActiveId((current) => current === id ? null : current);
    showToast("Модуль удален");
  }

  const handleCheckChange = useCallback(async (taskIndex: number, checked: boolean) => {
    if (!activeModule) return;
    const moduleId = activeModule.id;

    setState((current) => ({
      ...current,
      checks: {
        ...current.checks,
        [moduleId]: {
          ...(current.checks[moduleId] || {}),
          [String(taskIndex)]: checked
        }
      }
    }));

    try {
      await api.updateCheck(moduleId, taskIndex, checked);
    } catch (err) {
      showToast(err instanceof Error ? err.message : "Не удалось сохранить прогресс");
      await loadState();
    }
  }, [activeModule, loadState, showToast]);

  const openGlossary = useCallback((slug: string) => {
    const url = `${window.location.origin}${window.location.pathname}#/glossary/${encodeURIComponent(slug)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  }, []);

  const activeChecks = useMemo(
    () => (activeModule ? state.checks[activeModule.id] || emptyChecks : emptyChecks),
    [state.checks, activeModule]
  );

  function closeGlossary() {
    window.location.hash = "";
  }

  function handleCreateGlossaryTerm(selectedText: string) {
    setGlossaryDraftTerm(selectedText);
  }

  async function handleSubmitGlossaryTerm(input: UpsertGlossaryInput, adminToken: string) {
    await api.upsertGlossaryTerm(input, adminToken);
    const terms = await api.listGlossary();
    setGlossaryTerms(terms);
    showToast("Мануал сохранён");
  }

  return (
    <div id="app">
      <header id="topbar">
        <div className="brand">
          <span className="eyebrow">Fullstack Developer</span>
          <h1>Журнал подготовки по стеку</h1>
        </div>
        <div className="spacer" />
        <div className="gauge-wrap" aria-label={`Прогресс ${progress}%`}>
          <Activity size={17} />
          <span className="gauge-label">Пройдено</span>
          <div className="gauge"><div className="gauge-fill" style={{ width: `${progress}%` }} /></div>
          <span className="gauge-pct">{progress}%</span>
        </div>
      </header>

      <div id="body">
        <ModuleSidebar
          modules={state.modules}
          checks={state.checks}
          activeId={activeModule?.id || null}
          onSelect={setActiveId}
          onDelete={handleDeleteModule}
          onOpenImport={() => setImportOpen(true)}
        />

        <main id="content">
          <div id="content-inner">
            {glossarySlug ? (
              <GlossaryPage slug={glossarySlug} onClose={closeGlossary} />
            ) : (
              <>
                {loading && <div id="empty-state"><h2>Загружаем проект</h2><p>Поднимаем API и читаем состояние журнала.</p></div>}
                {!loading && error && (
                  <div id="empty-state" className="error-state">
                    <AlertTriangle size={28} />
                    <h2>API недоступен</h2>
                    <p>{error}</p>
                  </div>
                )}
                {!loading && !error && (
                  <ModuleContent
                    module={activeModule}
                    checks={activeChecks}
                    onCheckChange={handleCheckChange}
                    glossaryMatcher={glossaryMatcher}
                    onOpenGlossary={openGlossary}
                    onCreateGlossaryTerm={handleCreateGlossaryTerm}
                  />
                )}
              </>
            )}
          </div>
        </main>
      </div>

      <ImportModal open={importOpen} onClose={() => setImportOpen(false)} onSubmit={handleCreateModule} />
      <GlossaryAdminModal
        open={glossaryDraftTerm !== null}
        initialTerm={glossaryDraftTerm || ""}
        onClose={() => setGlossaryDraftTerm(null)}
        onSubmit={handleSubmitGlossaryTerm}
      />
      <Toast message={toast} />
    </div>
  );
}