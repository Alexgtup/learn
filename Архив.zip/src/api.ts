import type { AppStateDto, CreateModuleInput, ModuleItem } from "../shared/types";
import type { GlossaryTerm, GlossaryTermSummary, UpsertGlossaryInput } from "../shared/types";

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers
    }
  });

  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(body?.message || `Request failed: ${response.status}`);
  }

  if (response.status === 204) {
    return undefined as T;
  }

  return response.json() as Promise<T>;
}

export const api = {
  getState: () => request<AppStateDto>("/api/state"),

  createModule: (input: CreateModuleInput) =>
    request<ModuleItem>("/api/modules", {
      method: "POST",
      body: JSON.stringify(input)
    }),

  deleteModule: (id: string) =>
    request<void>(`/api/modules/${encodeURIComponent(id)}`, {
      method: "DELETE"
    }),

  updateCheck: (moduleId: string, taskIndex: number, checked: boolean) =>
    request<Record<string, boolean>>(`/api/checks/${encodeURIComponent(moduleId)}`, {
      method: "PATCH",
      body: JSON.stringify({ taskIndex, checked })
    }),
  listGlossary: () => request<GlossaryTermSummary[]>("/api/glossary"),
  getGlossaryTerm: (slug: string) => request<GlossaryTerm>(`/api/glossary/${encodeURIComponent(slug)}`),
  upsertGlossaryTerm: (input: UpsertGlossaryInput, adminToken: string) =>
    request<GlossaryTerm>("/api/glossary", {
      method: "POST",
      headers: { "x-admin-token": adminToken },
      body: JSON.stringify(input)
    }),
  deleteGlossaryTerm: (slug: string, adminToken: string) =>
    request<void>(`/api/glossary/${encodeURIComponent(slug)}`, {
      method: "DELETE",
      headers: { "x-admin-token": adminToken }
    })

};
