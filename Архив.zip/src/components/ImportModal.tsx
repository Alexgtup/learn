import { useRef, useState } from "react";
import { X } from "lucide-react";
import type { CreateModuleInput } from "../../shared/types";

type ImportModalProps = {
  open: boolean;
  onClose: () => void;
  onSubmit: (input: CreateModuleInput) => Promise<void>;
};

export function ImportModal({ open, onClose, onSubmit }: ImportModalProps) {
  const [title, setTitle] = useState("");
  const [week, setWeek] = useState("Мои модули");
  const [content, setContent] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);

  if (!open) return null;

  function resetAndClose() {
    setTitle("");
    setWeek("Мои модули");
    setContent("");
    setSubmitting(false);
    if (fileRef.current) fileRef.current.value = "";
    onClose();
  }

  async function handleFile(file: File | undefined) {
    if (!file) return;
    setContent(await file.text());
    if (!title) {
      setTitle(file.name.replace(/\.(md|markdown|txt)$/i, "").replace(/[_-]/g, " "));
    }
  }

  async function handleSubmit() {
    if (!content.trim()) return;
    setSubmitting(true);
    await onSubmit({ title, week, content });
    resetAndClose();
  }

  return (
    <div className="modal-overlay" onMouseDown={(event) => event.target === event.currentTarget && resetAndClose()}>
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby="import-title">
        <button className="btn btn-ghost modal-close" onClick={resetAndClose} aria-label="Закрыть">
          <X size={16} />
        </button>
        <h2 id="import-title">Новый модуль</h2>
        <p className="sub">Вставь markdown-текст или загрузи .md файл - он появится в списке слева.</p>

        <div className="row2">
          <div className="field">
            <label htmlFor="module-title">Название модуля</label>
            <input id="module-title" type="text" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Например: SQL и базы данных" />
          </div>
          <div className="field">
            <label htmlFor="module-week">Группа</label>
            <input id="module-week" type="text" value={week} onChange={(event) => setWeek(event.target.value)} />
          </div>
        </div>

        <div className="field">
          <label htmlFor="module-file">Загрузить файл</label>
          <input id="module-file" ref={fileRef} type="file" accept=".md,.markdown,.txt" onChange={(event) => handleFile(event.target.files?.[0])} />
        </div>

        <div className="field">
          <label htmlFor="module-content">Или вставь текст</label>
          <textarea id="module-content" value={content} onChange={(event) => setContent(event.target.value)} placeholder={"# Заголовок\n\n## День 1\n### Теория\n...\n### Практика\n- [ ] Задача"} />
        </div>

        <div className="modal-actions">
          <button className="btn" onClick={resetAndClose}>Отмена</button>
          <button className="btn btn-primary" onClick={handleSubmit} disabled={submitting || !content.trim()}>
            {submitting ? "Добавляем..." : "Добавить модуль"}
          </button>
        </div>
      </div>
    </div>
  );
}
