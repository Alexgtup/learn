import { Plus, Trash2 } from "lucide-react";
import type { CheckMap, ModuleItem } from "../../shared/types";
import { countTasks } from "../markdown";

type ModuleSidebarProps = {
  modules: ModuleItem[];
  checks: CheckMap;
  activeId: string | null;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  onOpenImport: () => void;
};

export function ModuleSidebar({ modules, checks, activeId, onSelect, onDelete, onOpenImport }: ModuleSidebarProps) {
  const groups = modules.reduce<Record<string, { order: number; items: ModuleItem[] }>>((acc, module) => {
    const key = module.week || "Модули";
    acc[key] ||= { order: module.weekOrder ?? 50, items: [] };
    acc[key].items.push(module);
    return acc;
  }, {});

  let counter = 0;

  return (
    <nav id="sidebar">
      <div id="sidebar-groups">
        {Object.entries(groups)
          .sort(([, a], [, b]) => a.order - b.order)
          .map(([week, group]) => (
            <div className="week-group" key={week}>
              <div className="week-label">{week}</div>
              {group.items
                .slice()
                .sort((a: ModuleItem, b: ModuleItem) => (a.order ?? 0) - (b.order ?? 0))
                .map((module: ModuleItem) => {
                  counter += 1;
                  const total = countTasks(module.content);
                  const checked = Object.values(checks[module.id] || {}).filter(Boolean).length;
                  const pct = total ? Math.round((checked / total) * 100) : 0;

                  return (
                    <div className={`module-row ${module.id === activeId ? "active" : ""}`} key={module.id} onClick={() => onSelect(module.id)}>
                      <div className="module-index">{String(counter).padStart(2, "0")}</div>
                      <div className="module-main">
                        <div className="module-title">{module.title}</div>
                        {total > 0 && (
                          <div className="module-progress-row">
                            <div className="module-bar"><div className="module-bar-fill" style={{ width: `${pct}%` }} /></div>
                            <span className="module-frac">{checked}/{total}</span>
                          </div>
                        )}
                      </div>
                      <button
                        className="btn-ghost module-del"
                        title="Удалить модуль"
                        onClick={(event) => {
                          event.stopPropagation();
                          onDelete(module.id);
                        }}
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  );
                })}
            </div>
          ))}
      </div>

      <div id="sidebar-footer">
        <button className="btn btn-primary sidebar-action" onClick={onOpenImport}>
          <Plus size={16} /> Модуль
        </button>
      </div>
    </nav>
  );
}
